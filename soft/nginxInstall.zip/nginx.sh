#!/bin/bash
#nginx.sh

#判断此目录是否出现了install.lock 就不能执行了

#定义一个打印方法
function print(){
 info=$1
 color=$2
 if [ $# -gt 1 ]; then
  color=$2
 fi
 echo -e "\033[$color;40m $info \033[0m"
}

#安装 c
yum install -y gcc gcc-c++

#定义主目录
basepath=$(cd `dirname $0`;pwd)

#lock file
lock_file="${basepath}/install.lock"
if [ -f "$lock_file" ]; then
 print "nginx server is installted if your reinstall please delete ./install.lock"
 exit
fi

#判断 如果 这四个文件有其中一个不存在就不执行


if [ ! -f "${basepath}/openssl-1.0.1c.tar.gz" ]; then
  print "openssl-1.0.1c.tar.gz file not exists" 31
  exit
fi

if [ ! -f "${basepath}/zlib-1.2.8.tar.gz" ]; then
  print "zlib-1.2.8.tar.gz file not exists" 31
  exit
fi

if [ ! -f "${basepath}/pcre-8.38.tar.gz" ]; then
  print "pcre-8.38.tar.gz file not exists" 31
  exit
fi

if [ ! -f "${basepath}/nginx-1.6.3.tar.gz" ]; then
  print "nginx-1.6.3.tar.gz file not exists" 31
  exit
fi

#创建运行新用户

groupadd -r nginx
useradd -g nginx -s /sbin/nologin -r nginx


#解压 openssl-1.0.1c.tar.gz
print "tar xf openssl-1.0.1c.tar.gz"

tar -xf openssl-1.0.1c.tar.gz
cd openssl-1.0.1c
./config
make && make install

#解压zlib-1.2.8.tar.gz
cd "${basepath}"
tar -xf zlib-1.2.8.tar.gz
print "tar -xf zlib" 32
cd zlib-1.2.8
./configure
make && make install


#解压pcre-8.38.tar.gz
cd "${basepath}"
tar -xf pcre-8.38.tar.gz
cd pcre-8.38
./configure
make && make install


#安装nginx
cd "${basepath}"
mkdir -p "/usr/local/nginx"
tar -xf nginx-1.6.3.tar.gz
cd nginx-1.6.3

#./configure --with-pcre=$pcre_path --with-zlib=$zlib_path --with-openssl=$openssl_path --with-http_ssl_module --with-http_stub_status_module
./configure --with-pcre=${basepath}/pcre-8.38 --with-zlib=${basepath}/zlib-1.2.8 --with-openssl=${basepath}/openssl-1.0.1c  --with-http_ssl_module --with-http_stub_status_module
make && make install

print "nginx success ok...." 32

(
cat << "EOF"
#!/bin/sh
#
#nginx - this script starts and stops the nginx daemon 
# 
# chkconfig:   - 85 15 
# description: Nginx is an HTTP(S) server, HTTP(S) reverse \ 
#               proxy and IMAP/POP3 proxy server 
# processname: nginx 
# config:      /etc/nginx/nginx.conf 
# config:      /etc/sysconfig/nginx 
# pidfile:     /var/run/nginx.pid 

# Source function library. 
. /etc/rc.d/init.d/functions 

# Source networking configuration. 
. /etc/sysconfig/network 

# Check that networking is up. 
[ "$NETWORKING" = "no" ] && exit 0 

nginx="/usr/local/nginx/sbin/nginx" 
prog=$(basename $nginx)

NGINX_CONF_FILE="/usr/local/nginx/conf/nginx.conf" 

[ -f /etc/sysconfig/nginx ] && . /etc/sysconfig/nginx 

lockfile=/var/lock/subsys/nginx 

start() { 
    [ -x $nginx ] || exit 5 
    [ -f $NGINX_CONF_FILE ] || exit 6 
    echo -n $"Starting $prog: " 
    daemon $nginx -c $NGINX_CONF_FILE 
    retval=$? 
    echo 
    [ $retval -eq 0 ] && touch $lockfile 
    return $retval 
} 

stop() { 
    echo -n $"Stopping $prog: " 
    killproc $prog -QUIT 
    retval=$? 
    echo 
    [ $retval -eq 0 ] && rm -f $lockfile 
    return $retval 
killall -9 nginx 
} 

restart() { 
    configtest || return $? 
    stop 
    sleep 1 
    start 
} 

reload() { 
    configtest || return $? 
    echo -n $"Reloading $prog: " 
    killproc $nginx -HUP 
RETVAL=$? 
    echo 
} 

force_reload() { 
    restart 
} 

configtest() { 
$nginx -t -c $NGINX_CONF_FILE 
} 

rh_status() { 
    status $prog 
} 

rh_status_q() { 
    rh_status >/dev/null 2>&1 
} 

case "$1" in 
    start) 
        rh_status_q && exit 0 
    $1 
        ;; 
    stop) 
        rh_status_q || exit 0 
        $1 
        ;; 
    restart|configtest) 
        $1 
        ;; 
    reload) 
        rh_status_q || exit 7 
        $1 
        ;; 
    force-reload) 
        force_reload 
        ;; 
    status) 
        rh_status 
        ;; 
    condrestart|try-restart) 
        rh_status_q || exit 0 
            ;; 
    *)    
      echo $"Usage: $0 {start|stop|status|restart|condrestart|try-restart|reload|force-reload|configtest}" 
        exit 2 

esac
EOF
) > /etc/init.d/nginx

chmod 755 /etc/init.d/nginx
chkconfig nginx on

print nginx is run 32

service nginx start
















