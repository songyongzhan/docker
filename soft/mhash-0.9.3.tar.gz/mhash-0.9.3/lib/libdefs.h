#ifndef LIBDEFS_H
#define LIBDEFS_H

/*
   {{{ includes 
 */

#include <mutils.h>
#include <mglobal.h>
#include <mtypes.h>

#ifdef WIN32
# define WIN32DLL_DEFINE __declspec( dllexport)
#else
# define WIN32DLL_DEFINE
#endif

#if !defined(byte)
#define byte unsigned char
#endif

#define RAND32 (mutils_word32) ((mutils_word32)rand() << 17 ^ (mutils_word32)rand() << 9 ^ rand())

#endif
