<?php 

namespace Phalcon\Image {

	/**
	 * Phalcon\Image\Exception
	 *
	 * Exceptions thrown in Phalcon\Image will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
