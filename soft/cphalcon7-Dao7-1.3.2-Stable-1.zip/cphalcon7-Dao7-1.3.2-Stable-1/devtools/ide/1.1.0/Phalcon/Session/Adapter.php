<?php 

namespace Phalcon\Session {

	/**
	 * Phalcon\Session\Adapter
	 *
	 * Base class for Phalcon\Session adapters
	 */
	
	abstract class Adapter implements \Phalcon\Session\AdapterInterface, \Countable, \IteratorAggregate, \Traversable, \ArrayAccess {

		protected $_uniqueId;

		protected $_started;

		protected $_options;

		protected $_expire;

		protected $_path;

		protected $_secure;

		protected $_domain;

		protected $_httpOnly;

		/**
		 * \Phalcon\Session\Adapter constructor
		 *
		 * @param array $options
		 * @param int $expire
		 * @param string $path
		 * @param boolean $secure
		 * @param string $domain
		 * @param boolean $httpOnly
		 */
		public function __construct($options=null, $expire=null, $path=null, $secure=null, $domain=null, $httpOnly=null){ }


		public function __destruct(){ }


		/**
		 * Starts the session (if headers are already sent the session will not be started)
		 *
		 * @return boolean
		 */
		public function start(){ }


		/**
		 * Sets session's options
		 *
		 *<code>
		 *	$session->setOptions(array(
		 *		'uniqueId' => 'my-private-app'
		 *	));
		 *</code>
		 *
		 * @param array $options
		 */
		public function setOptions($options){ }


		/**
		 * Get internal options
		 *
		 * @return array
		 */
		public function getOptions(){ }


		/**
		 * Gets a session variable from an application context
		 *
		 * @param string $index
		 * @param mixed $defaultValue
		 * @param bool $remove
		 * @return mixed
		 */
		public function get($index, $defaultValue=null){ }


		/**
		 * Sets a session variable in an application context
		 *
		 *<code>
		 *	$session->set('auth', 'yes');
		 *</code>
		 *
		 * @param string $index
		 * @param string $value
		 */
		public function set($index, $value){ }


		/**
		 * Sets a session variables in an application context
		 *
		 *<code>
		 *	$session->sets(array('auth', 'yes'));
		 *</code>
		 *
		 * @param array $data
		 */
		public function sets($data){ }


		/**
		 * Check whether a session variable is set in an application context
		 *
		 *<code>
		 *	var_dump($session->has('auth'));
		 *</code>
		 *
		 * @param string $index
		 * @return boolean
		 */
		public function has($index){ }


		/**
		 * Removes a session variable from an application context
		 *
		 *<code>
		 *	$session->remove('auth');
		 *</code>
		 *
		 * @param string $index
		 */
		public function remove($index){ }


		/**
		 * Returns active session id
		 *
		 *<code>
		 *	echo $session->getId();
		 *</code>
		 *
		 * @return string
		 */
		public function getId(){ }


		/**
		 * Check whether the session has been started
		 *
		 *<code>
		 *	var_dump($session->isStarted());
		 *</code>
		 *
		 * @return boolean
		 */
		public function isStarted(){ }


		/**
		 * Destroys the active session
		 *
		 *<code>
		 *	var_dump($session->destroy());
		 *</code>
		 *
		 * @return boolean
		 */
		public function destroy($session_id=null){ }


		public function __get($property){ }


		public function __set($property, $value){ }


		public function __isset($property){ }


		public function __unset($property){ }


		public function offsetGet($property){ }


		public function offsetSet($property, $value){ }


		public function offsetExists($property){ }


		public function offsetUnset($property){ }


		public function count(){ }


		public function getIterator(){ }


		/**
		 * Set the current session id
		 *
		 *<code>
		 *	$session->setId($id);
		 *</code>
		 */
		public function setId($sid){ }

	}
}
