<?php 

namespace Phalcon\Mvc\Url {

	/**
	 * Phalcon\Mvc\Url\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Url will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
