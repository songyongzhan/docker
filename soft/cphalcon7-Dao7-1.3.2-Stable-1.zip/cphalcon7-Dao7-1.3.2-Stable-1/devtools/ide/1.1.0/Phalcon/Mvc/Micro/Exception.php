<?php 

namespace Phalcon\Mvc\Micro {

	/**
	 * Phalcon\Mvc\Micro\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Micro will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
