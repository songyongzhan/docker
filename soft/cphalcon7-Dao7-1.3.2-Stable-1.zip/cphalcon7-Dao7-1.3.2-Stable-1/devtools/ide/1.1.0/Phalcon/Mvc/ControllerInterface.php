<?php 

namespace Phalcon\Mvc {

	/**
	 * Phalcon\Mvc\ControllerInterface initializer
	 */
	
	interface ControllerInterface {
	}
}
