<?php 

namespace Phalcon\Mvc\User {

	/**
	 * Phalcon\Mvc\User\Plugin
	 *
	 * This class can be used to provide user plugins an easy access to services
	 * in the application
	 */
	
	class Plugin extends \Phalcon\Di\Injectable implements \Phalcon\Events\EventsAwareInterface, \Phalcon\Di\InjectionAwareInterface {
	}
}
