<?php 

namespace Phalcon\Mvc\Model\Query {

	/**
	 * Phalcon\Mvc\Model\Query\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Model\Query\* classes will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Mvc\Model\Exception implements \Throwable {
	}
}
