<?php 

namespace Phalcon\Mvc\JsonRpc {

	/**
	 * Phalcon\Mvc\JsonRpc\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\JsonRpc class will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
