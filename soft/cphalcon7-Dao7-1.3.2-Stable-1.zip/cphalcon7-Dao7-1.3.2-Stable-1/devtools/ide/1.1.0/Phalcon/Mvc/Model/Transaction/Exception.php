<?php 

namespace Phalcon\Mvc\Model\Transaction {

	/**
	 * Phalcon\Mvc\Model\Transaction\Exception
	 *
	 * Exceptions thrown in Phalcon\Mvc\Model\Transaction will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Mvc\Model\Exception implements \Throwable {
	}
}
