<?php 

namespace Phalcon\Mvc\View {

	/**
	 * Phalcon\Mvc\View\Exception
	 *
	 * Class for exceptions thrown by Phalcon\Mvc\View
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
