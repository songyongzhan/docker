<?php 

namespace Phalcon\Annotations {

	/**
	 * Phalcon\Annotations\Exception
	 *
	 * Exceptions thrown in Phalcon\Annotations will use this class
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
