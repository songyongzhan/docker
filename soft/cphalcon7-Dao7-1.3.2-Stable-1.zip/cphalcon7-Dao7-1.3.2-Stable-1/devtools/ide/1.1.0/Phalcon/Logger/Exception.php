<?php 

namespace Phalcon\Logger {

	/**
	 * Phalcon\Logger\Exception
	 *
	 * Exceptions thrown in Phalcon\Logger will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
