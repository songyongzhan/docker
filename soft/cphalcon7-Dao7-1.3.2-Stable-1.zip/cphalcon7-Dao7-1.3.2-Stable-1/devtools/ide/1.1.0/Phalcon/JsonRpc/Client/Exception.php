<?php 

namespace Phalcon\JsonRpc\Client {

	/**
	 * Phalcon\JsonRpc\Client\Exception
	 *
	 * Exceptions thrown in Phalcon\JsonRpc\Client will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
