<?php 

namespace Phalcon\Config {

	/**
	 * Phalcon\Config\Exception
	 *
	 * Exceptions thrown in Phalcon\Config will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
