<?php 

namespace Phalcon\Application {

	/**
	 * Phalcon\Application\Exception
	 *
	 * Exceptions thrown in Phalcon\Application will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
