<?php 

namespace Phalcon\Cli\Router {

	/**
	 * Phalcon\Cli\Router\Exception
	 *
	 * Exceptions thrown in Phalcon\Cli\Router will use this class
	 *
	 */
	
	class Exception extends \Phalcon\Exception implements \Throwable {
	}
}
